import { Component, inject, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { ProductService } from '../../Services/product.service';
import { ToastrService } from 'ngx-toastr';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-product-manager',
  templateUrl: './product.component.html',
  styleUrl: './product.component.css',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule]
})
export class ProductComponent implements OnInit {
  products: any;
  showForm = false;
  viewForm = false;
  formType: 'add' | 'edit' | 'view' | null = null;
  selectedProduct: any = null;
  private toastr: ToastrService;
  maxDate = new Date().toISOString().split('T')[0];


    productForm = new FormGroup({
    productName: new FormControl('', [Validators.required, Validators.maxLength(10)]),
    productCode: new FormControl('', [Validators.required, Validators.pattern('^[a-zA-Z0-9_]{6}$')]),
    productImagePath: new FormControl<string | null>(null),
    category: new FormControl('', [Validators.required, Validators.maxLength(10)]),
    brand: new FormControl('', [Validators.required, Validators.maxLength(10)]),
    sellingPrice: new FormControl('', [Validators.required, Validators.min(0.01)]),
    purchasePrice: new FormControl('', [Validators.required, Validators.min(0.01)]),
    purchaseDate: new FormControl('', Validators.required),
    stock: new FormControl('', [Validators.required, Validators.min(0)])
  });

  constructor(private productService: ProductService) {
    this.toastr = inject(ToastrService);

  }

  ngOnInit() {
    this.loadProducts();
  }

  loadProducts() {
    this.productService.getProducts().subscribe((res:any) => {
      this.products = res?.data;
      console.log('Products: ', this.products);
    });
  }

  openForm(type: 'add' | 'edit' | 'view', product?: any) {
    this.formType = type;
    this.selectedProduct = product || null;
    if (type === 'edit' && product) {
      this.showForm = true;
      this.productForm.patchValue(product);
    } 
    else if(type === 'view' && product){
      this.viewForm = true;
    }
    else if (type === 'add') {
      this.showForm = true;
      this.productForm.reset();
    }
  }

  closeForm() {
    this.showForm = false;
    this.viewForm = false;
    this.formType = null;
    this.selectedProduct = null;
    this.productForm.reset();
    this.loadProducts();
  }

  onFileChange(event: any) {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        this.productForm.patchValue({
          productImagePath: reader.result as string
        });
      };
      reader.readAsDataURL(file);
    }
  }

  submitForm() {
    if (this.productForm.invalid ) {
      this.toastr.error('Please fill in all required fields correctly.');
      this.productForm.markAllAsTouched();

      return;
    }

    const formData = this.productForm.value;
    console.log("formData-----",formData)
    if (this.formType === 'edit' && this.selectedProduct) {
      this.productService.updateProduct(this.selectedProduct.id, formData).subscribe((res:any) => {
        console.log("rewwww---",res)
        this.toastr.success('Product updated successfully.');
        this.closeForm();
        this.loadProducts();
      });
    } else {
      this.productService.addProduct(formData).subscribe(() => {
        this.toastr.success('Product added successfully.');
        this.closeForm();
        this.loadProducts();
      });
    }
  }

  // deleteProduct(productId: number) {
  //   this.productService.deleteProduct(productId).subscribe(() => {
  //     this.loadProducts();
  //     this.toastr.success('Product Deleted Successfully!');
  //   });
  // }

  deleteProduct(productId: number) {
    this.productService.deleteProduct(productId).subscribe(() => {
      this.loadProducts();
      Swal.fire({
        icon: 'success',
        title: 'Product Deleted Successfully!',
        showConfirmButton: false,
        timer: 1500
      });
    });
  }

  
  
}
