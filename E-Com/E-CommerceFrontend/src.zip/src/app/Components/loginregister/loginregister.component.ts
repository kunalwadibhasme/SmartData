import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router'; // Corrected import
import { ToastrService } from 'ngx-toastr';
import { LoginregisterService } from '../../Services/loginregister.service';

@Component({
  selector: 'app-loginregister',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './loginregister.component.html',
  styleUrls: ['./loginregister.component.css'] // Corrected styleUrls
})
export class LoginregisterComponent {
  title = 'E-CommerceFrontend';
  
  // Correctly inject Router and ToastrService
  private toastr: ToastrService;
  private router: Router;

  constructor(private loginregisterService:LoginregisterService) {
    this.toastr = inject(ToastrService);
    this.router = inject(Router);
    sessionStorage.setItem('isLoggedIn','false');
  }

  // Set maxDate to today's date 
  maxDate = new Date().toISOString().split('T')[0];

  activeForm: string = 'login'; // to toggle between login and register forms

  loginForm: FormGroup = new FormGroup({
    userName: new FormControl('', [Validators.required, Validators.minLength(5), Validators.maxLength(20)]),
    password: new FormControl('', [Validators.required, Validators.minLength(6), Validators.maxLength(15)]),
  });

  forgetpasswordForm: FormGroup = new FormGroup({
    email: new FormControl('', [Validators.required, Validators.email, Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$"), Validators.minLength(5), Validators.maxLength(30)]),
  });


  // Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$"),
  // Validators.required,
  // Validators.email,
  // Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$"),
  registerForm = new FormGroup({
    firstName: new FormControl('', [Validators.required, Validators.minLength(2), Validators.maxLength(15)]),
    lastName: new FormControl('', [Validators.required, Validators.minLength(2), Validators.maxLength(15)]),
    email: new FormControl('', [Validators.required, Validators.email, Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$"), Validators.minLength(5), Validators.maxLength(30)]),
    usertypeId: new FormControl('', Validators.required),
    dateOfBirth: new FormControl('', Validators.required),
    mobile: new FormControl('', [Validators.required, Validators.pattern("^[0-9]{10}$")]),
    address: new FormControl('', [Validators.required, Validators.minLength(5), Validators.maxLength(40)]),
    zipCode: new FormControl('', [Validators.required, Validators.pattern("^[0-9]{6}$")]),
    profileimage: new FormControl('', Validators.required), // Make the type string for base64
    stateId: new FormControl('', Validators.required),
    countryId: new FormControl('', Validators.required),
  });

  
  usertypedata : any;
  statedatas : any;
  countrydatas : any;

  toggleForm(formType: string) {
    this.activeForm = formType;
    this.loginForm.reset();
    this.registerForm.reset();
    if(this.activeForm === 'register')
      {

        this.getusertypedata();
        this.getcountrydata();
      }
  }

  getusertypedata()
  {
    this.loginregisterService.getUserType().subscribe({
      next: (value:any) =>{
        this.usertypedata = value;
        console.log("usertypedata : ",this.usertypedata);
      }   
    });
  }

  getcountrydata()
  {
    this.loginregisterService.getCountry().subscribe({
      next: (value:any) =>{
        this.countrydatas = value;
        console.log("countrydata : ",this.countrydatas);
      }   
    });
  }

  getstatedatabycountryid(id:any)
  {
    const selectedCountryId = parseInt((id.target as HTMLSelectElement).value);
    console.log(selectedCountryId,'selectedCountryId');

    this.loginregisterService.getStateByCountryId(selectedCountryId).subscribe(res => {
      console.log(res, 'status response by country id');
      if (res) {
        this.statedatas = res;
      }else{
        alert('State for selected Country not found');
      }
    });
  }

  base64Image: string = ''; // To store the Base64 image string

  onRegisterSubmit() {
    if (this.registerForm.invalid) {
      this.registerForm.markAllAsTouched();
      this.toastr.error('Please fill in all required fields correctly.');
      return;
    }
  
    const registerData = {
      ...this.registerForm.value,
      profileimage: this.base64Image, // Add the Base64 string to the data object
    };
    this.loginregisterService.register(registerData).subscribe({
      next: (res: any) => {
        if (res.statusCode == 200) {
          console.log('Register Form Submitted', res);
          this.registerForm.reset();
          this.loginForm.reset();
          this.activeForm = 'login';
          this.toastr.success('Registration successful!');
        }
        else{
        this.toastr.error('Registration failed.');
        }
      },
      error: (err: any) => {
        console.error(err);
        this.toastr.error('Registration failed. Please try again.');
      },
    });
  }
  


  onFileChange(event: any) {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        this.base64Image = reader.result as string; // Store Base64 string in a variable
      };
      reader.readAsDataURL(file);
    }
  }
      
  onLoginSubmit() {
    if (this.loginForm.invalid) {
      this.loginForm.markAllAsTouched();
      this.toastr.error('Please fill in all required fields correctly.');
      return;
    }
    const loginData = this.loginForm.value;
    this.loginregisterService.login(loginData.userName, loginData.password).subscribe({
      next:(res:any)=>{
        console.log(res)
        if(res.status==200){
          sessionStorage.setItem('Token', res.token);
          sessionStorage.setItem('userid',res.data.usertableId)
          sessionStorage.setItem('usertypeid',res.data.usertypeId);
          sessionStorage.setItem('email',res.data.email);
          console.log('Login Form Submitted', loginData);
          // this.router.navigate(['verify']);
          this.router.navigateByUrl('/verify');
          // Example of what you might do after form submission
          this.toastr.success('Verification OTP sent to Mail');
        }
        else if(res.status == 404)
        {
          this.toastr.error('Invalid UserName or Password');

        }
      }
    });
  }

  onForgetPasswordSubmit(){
    console.log("this====",this.forgetpasswordForm.value);
    if(this.forgetpasswordForm.invalid){
      this.forgetpasswordForm.markAllAsTouched();
      this.toastr.error('Please fill the Email Address Correctly');
      return;
    }
    this.loginregisterService.ForgetPassword(this.forgetpasswordForm.value.email).subscribe({
      next:(res:any)=>{
        if(res.status == 200){
          this.toastr.success('New Password Sent Successfully on your mail');
          this.activeForm = 'login';
          this.forgetpasswordForm.reset();
        }
      }
    })
  }
}
