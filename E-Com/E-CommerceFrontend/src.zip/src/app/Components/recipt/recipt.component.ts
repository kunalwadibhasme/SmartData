import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { AddtoCartService } from '../../Services/addto-cart.service';
import { Route, Router } from '@angular/router';

@Component({
  selector: 'app-recipt',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './recipt.component.html',
  styleUrl: './recipt.component.css'
})
export class ReciptComponent {

closeModel() {
  this.router.navigateByUrl('/dashboard');
  this.isvisible=false;
  this.respData =[];
}

isvisible:boolean = true;
respData:any;
allow : boolean = true;
usertypeid = sessionStorage.getItem('usertypeid');
constructor(private cartService : AddtoCartService, private router:Router ){

}
ngOnInit()
{
  if(this.usertypeid !='2')
    {
        this.allow = false;
    }
  const userid = sessionStorage.getItem('userid');
  this.GetReceiptData(userid);
}

GetReceiptData(userid : any){
  this.cartService.GenerateReceipt(userid).subscribe((res : any)=>{
    console.log("ReceiptData : ", res);
    this.respData = res;
  });
}


}





