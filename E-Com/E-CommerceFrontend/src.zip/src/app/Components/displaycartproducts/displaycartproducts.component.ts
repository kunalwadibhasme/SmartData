import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { AddtoCartService } from '../../Services/addto-cart.service';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import Swal from 'sweetalert2';
import { Router } from '@angular/router';


interface CartItem {
  id: number;
  brand: string;
  productName: string;
  productCode: string;
  sellingPrice: number;
  quantity: number;
}


@Component({
  selector: 'app-displaycartproducts',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './displaycartproducts.component.html',
  styleUrl: './displaycartproducts.component.css'
})
export class DisplaycartproductsComponent {

  cartItems: CartItem[] = [];
  subtotal: number = 0;
  isVisible: boolean = false;
  paymentForm: FormGroup;
  constructor(private cartService: AddtoCartService, private fb: FormBuilder, private toastr: ToastrService, private router:Router) {
    this.paymentForm = this.fb.group({
      cardNumber: ['', [Validators.required, Validators.pattern('^[0-9]{16}$')]],
      expiryDate: ['', [Validators.required, Validators.pattern('^(0[1-9]|1[0-2])\/?([0-9]{2})$')]],
      cvv: ['', [Validators.required, Validators.pattern('^[0-9]{3}$')]],
      amount: [this.subtotal]
    });
  }

  ngOnInit(): void {

    this.fetchCartProducts();
  }



  onSubmit() {
    const userId = sessionStorage.getItem('userid');
    if (this.paymentForm.valid) {
        // var credentials = this.paymentForm.value;

        
        this.cartService.ValidatePayment(this.paymentForm.value.cardNumber, this.paymentForm.value.expiryDate, this.paymentForm.value.cvv).subscribe(
            (response) => {
                if (response == true) {
                    //sweetAlert
                    Swal.fire({
                        title: "Payment Successful!",
                        text: "Your payment has been processed successfully.",
                        icon: "success",
                        confirmButtonColor: "#3085d6",
                        confirmButtonText: "OK"
                    }).then((result) => {
                        if (result.isConfirmed) {
                            console.log("Payment confirmed");
                            this.updatesalesdetail();
                            this.isVisible = false;
                            this.router.navigateByUrl('/receipt'); 
                        }
                    });
                } else {
                    
                    Swal.fire({
                        title: "Payment Failed",
                        text: "Your payment credentials are incorrect. Please try again.",
                        icon: "error",
                        confirmButtonColor: "#d33",
                        confirmButtonText: "OK"
                    });
                }
            },
            (error) => {
                // Handle error from API call
                Swal.fire({
                    title: "Payment Error",
                    text: "An error occurred while processing your payment. Please try again.",
                    icon: "error",
                    confirmButtonColor: "#d33",
                    confirmButtonText: "OK"
                });
            }
        );
    } else {
        
        this.paymentForm.markAllAsTouched();
    }
}


  updatesalesdetail(): void {
    const userid = sessionStorage.getItem('userid');
    this.cartService.Updatesalesdetail(userid, this.subtotal).subscribe((res: any) => {
      console.log("Updatesalesdetail =", res);
    });

  }




  onCancel() {
    this.isVisible = false;
    this.paymentForm.reset();
  }
  Back()
  {
    this.router.navigateByUrl('/dashboard');
  }


  fetchCartProducts(): void {
    const userid = sessionStorage.getItem('userid');
    this.cartService.getCartItems(userid).subscribe((res: any) => {
      console.log("cartItems ==", res);
      this.cartItems = res;
      console.log("this.cartItems==>>", this.cartItems);
      this.calculateSubtotal();
    });
  }

  calculateSubtotal(): void {
    this.subtotal = this.cartItems.reduce((acc, item) => acc + (item.sellingPrice * item.quantity), 0);
  }

  deleteItem(itemId: number): void {
    const userid = sessionStorage.getItem('userid');
    this.cartService.deleteCartItem(itemId, userid).subscribe(() => {
      this.cartItems = this.cartItems.filter(item => item.id !== itemId);
      this.calculateSubtotal();
      this.fetchCartProducts();
    });
  }

  pay(): void {
    if (this.cartItems.length === 0) {
    // Show error message
    this.toastr.error('Cart is empty. Please add items to the cart before proceeding.');
    return;
    }
    // Implement payment logic here
    this.paymentForm.reset();
    this.isVisible = true;
    }
    
}



